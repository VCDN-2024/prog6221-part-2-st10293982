﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RecipePOE;
using System;
using System.IO;

namespace RecipeTests
{
    [TestClass]
    public class CalorieWarningTests
    {
        [TestMethod]

        public void CheckCalories_ShouldDisplayWarning_WhenCaloriesExceed300()
        {
            double totalCalories = 350;

            using (StringWriter sw = new StringWriter())
            {

                Console.SetOut(sw);


                Warning.CheckCalories(totalCalories);


                string expected = "\nWarning: This recipe has a high calorie count of 350 calories.\n";

                Assert.IsTrue(sw.ToString().Contains(expected));

                Console.ResetColor();
            }
        }

        [TestMethod]

        public void CheckCalories_ShouldNotDisplayWarning_WhenCaloriesDoNotExceed300()
        {

            double totalCalories = 250;

            using (StringWriter sw = new StringWriter())
            {
                Console.SetOut(sw);


                Warning.CheckCalories(totalCalories);


                string expected = "\nWarning: This recipe has a high calorie count of 250 calories.\n";

                Assert.IsFalse(sw.ToString().Contains(expected));

                Console.ResetColor();
            }
        }
    }
}
