﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipePOE
{
        public class Warning
        {

            public static void CheckCalories(double totalCalories)
            {

                if (totalCalories > 300)
                {

                    Console.ForegroundColor = ConsoleColor.DarkRed;

                    Console.WriteLine($"\nWarning: This recipe has {totalCalories} calories!!!");

                    Console.ResetColor();

                }
            }
        }

    }

