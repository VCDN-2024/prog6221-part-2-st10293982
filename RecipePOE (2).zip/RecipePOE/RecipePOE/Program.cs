﻿// See https://aka.ms/new-console-template for more information


using RecipePOE;

Menu menu = new Menu();


while (true)
{
    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.WriteLine("\n===============================" +
        "\nWelcome to the Recipe App:" +
        "\n1. Add a new recipe" +
        "\n2. Display recipe" +
        "\n3. Delete a recipe" +
        "\n4. Press any key to Exit" +
        "\n===============================");
    Console.ResetColor();
    int Input = int.Parse(Console.ReadLine());

    switch (Input)
    {
        case 1:
            menu.AddRecipe(); 
            break;
        case 2:
            menu.Display();
            break;
        case 3:
            menu.Delete();
            break;
        case 4:
            return;

        default:
            Console.WriteLine("Invalid choice. Please select from the menu.");
            break;

    }
    continue;
}
